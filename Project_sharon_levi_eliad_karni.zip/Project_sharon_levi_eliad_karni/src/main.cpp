//============================= include section ==============================
#include "Controller.h"
#include <stdlib.h>
//============================== main section ================================
int main(){
	Controller controller;
	controller.run();
	return EXIT_SUCCESS;
}
