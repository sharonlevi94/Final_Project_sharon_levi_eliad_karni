//============================= include section ==============================
#include "StaticObject.h"
